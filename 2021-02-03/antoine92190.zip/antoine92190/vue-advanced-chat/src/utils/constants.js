export const IMAGE_TYPES = ['png', 'jpg', 'jpeg', 'webp', 'svg', 'gif']
export const VIDEO_TYPES = ['video/mp4', 'video/ogg', 'video/webm']
