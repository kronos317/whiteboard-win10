export = global;
declare var global: any;
