module.exports = {
	// configureWebpack: {
	//   ...(process.env.NODE_ENV === 'production'
	//     ? {
	//         externals: {
	//           'vue-infinite-loading': 'vue-infinite-loading'
	//         }
	//       }
	//     : {})
	// }
}
